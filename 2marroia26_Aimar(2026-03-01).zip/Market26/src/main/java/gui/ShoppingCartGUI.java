package gui;

import java.awt.EventQueue;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import businessLogic.BLFacade;
import configuration.UtilDate;
import domain.Sale;
import domain.Seller;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class ShoppingCartGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JFrame thisFrame;

	
	private JScrollPane scrollPanelProducts = new JScrollPane();
	private JTable tableProducts= new JTable();

	private DefaultTableModel tableModelProducts;
	
	private String[] columnNamesProducts = new String[] {
			ResourceBundle.getBundle("Etiquetas").getString("CreateSaleGUI.Title"), 
			ResourceBundle.getBundle("Etiquetas").getString("CreateSaleGUI.Price"),
			ResourceBundle.getBundle("Etiquetas").getString("CreateSaleGUI.PublicationDate"),

	};

	/**
	 * Create the frame.
	 */
	public ShoppingCartGUI(String mail) {
		thisFrame=this;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSCLabel = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("ShoppingCartGUI.SCLabel"));
		lblSCLabel.setBounds(57, 12, 346, 25);
		contentPane.add(lblSCLabel);
		
		
		
		scrollPanelProducts.setBounds(new Rectangle(33, 49, 384, 146));

		scrollPanelProducts.setViewportView(tableProducts);
		tableModelProducts = new DefaultTableModel(null, columnNamesProducts);
		tableProducts.setModel(tableModelProducts);

		tableModelProducts.setDataVector(null, columnNamesProducts);
		tableModelProducts.setColumnCount(4); // another column added to allocate ride objects

		tableProducts.getColumnModel().getColumn(0).setPreferredWidth(200);
		tableProducts.getColumnModel().getColumn(1).setPreferredWidth(10);
		tableProducts.getColumnModel().getColumn(1).setPreferredWidth(70);


		tableProducts.getColumnModel().removeColumn(tableProducts.getColumnModel().getColumn(3)); // not shown in JTable

		this.getContentPane().add(scrollPanelProducts, null);
		
		 		try {
					tableModelProducts.setDataVector(null, columnNamesProducts);
					tableModelProducts.setColumnCount(4); // another column added to allocate product object

					BLFacade facade = MainGUI.getBusinessLogic();
					List<Sale> SC= facade.getSellerSC(mail);
					
					if(!SC.isEmpty()) {
						for (Sale sale: SC){
							
							Vector<Object> row = new Vector<Object>();
							row.add(sale.getTitle());
							row.add(sale.getPrice());
							row.add(new SimpleDateFormat("dd-MM-yyyy").format(sale.getPublicationDate()));
							row.add(sale); // product object added in order to obtain it with tableModelProducts.getValueAt(i,2)
							tableModelProducts.addRow(row);		
						}
					}
					
				} catch (Exception e1) {

					e1.printStackTrace();
				}
				tableProducts.getColumnModel().getColumn(0).setPreferredWidth(200);
				tableProducts.getColumnModel().getColumn(1).setPreferredWidth(10);
				tableProducts.getColumnModel().getColumn(1).setPreferredWidth(70);

				tableProducts.getColumnModel().removeColumn(tableProducts.getColumnModel().getColumn(3)); // not shown in JTable
		 		
		
				tableProducts.addMouseListener(new MouseAdapter() {
			        @Override
			        public void mousePressed(MouseEvent mouseEvent) {
			            
			            if(mouseEvent.getClickCount() == 2)
			            {
					        JTable table =(JTable) mouseEvent.getSource();
			            	Point point = mouseEvent.getPoint();
					        int row = table.rowAtPoint(point);
			            	Sale s=(Sale) tableModelProducts.getValueAt(row, 3);
				            new ShowSaleGUI(s,mail);
			            }
			        }
				});
				
				
				
		JButton btnClose = new JButton(ResourceBundle.getBundle("Etiquetas").getString("ShoppingCartGUI.Close"));
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				thisFrame.setVisible(false);
			}
		});
		btnClose.setBounds(173, 219, 105, 27);
		contentPane.add(btnClose);

	}
}
