package gui;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;




import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;

import java.util.ResourceBundle;

import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;

public class BoughtGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JFrame thisFrame;


	/**
	 * Create the frame.
	 */
	public BoughtGUI() {
		thisFrame=this;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 326, 139);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBoughtLabel = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("BoughtGUI.Bought"));
		lblBoughtLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblBoughtLabel.setBounds(22, 12, 292, 25);
		contentPane.add(lblBoughtLabel);

			
		JButton btnClose = new JButton(ResourceBundle.getBundle("Etiquetas").getString("ShoppingCartGUI.Close"));
		btnClose.setBounds(116, 63, 105, 27);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				thisFrame.setVisible(false);
			}
		});
		contentPane.add(btnClose);

	}
}
