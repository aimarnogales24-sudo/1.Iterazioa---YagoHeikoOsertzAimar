package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.Seller;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

public class LoginGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_log;
	private JPasswordField textField_pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("LoginGUI.Login"));
		lblNewLabel.setBounds(41, 57, 126, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("LoginGUI.Password"));
		lblNewLabel_1.setBounds(41, 141, 126, 14);
		contentPane.add(lblNewLabel_1);
		
		textField_log = new JTextField();
		textField_log.setBounds(173, 54, 159, 20);
		contentPane.add(textField_log);
		textField_log.setColumns(10);
		
		textField_pass = new JPasswordField();
		textField_pass.setBounds(173, 138, 159, 20);
		contentPane.add(textField_pass);
		textField_pass.setColumns(10);
		
		JLabel lblIncPass = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("LoginGUI.lblIncPass")); //$NON-NLS-1$ //$NON-NLS-2$
		lblIncPass.setVisible(false);
		lblIncPass.setHorizontalAlignment(SwingConstants.CENTER);
		lblIncPass.setBounds(128, 220, 182, 17);
		contentPane.add(lblIncPass);
		
		JButton btnSaiatu = new JButton(ResourceBundle.getBundle("Etiquetas").getString("LoginGUI.Try"));
		btnSaiatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BLFacade facade = MainGUI.getBusinessLogic();
				
				boolean b=facade.isRegistered(textField_log.getText());
				
				if(b) {
					Seller lagun=facade.getSeller(textField_log.getText());
					if (lagun.getPass().compareTo(textField_pass.getText())!=0) {
						b=false;
						lblIncPass.setVisible(true);
					}
				}
				if(b) {
					new MainGUIerregistratua(textField_log.getText()).setVisible(true);;
				}else {
					
				}
				
			}
		});
		btnSaiatu.setBounds(128, 185, 182, 23);
		contentPane.add(btnSaiatu);
		
		

	}
}
