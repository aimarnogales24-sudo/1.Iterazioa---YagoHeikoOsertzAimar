package gui;

import java.awt.EventQueue;
import java.util.ResourceBundle;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import businessLogic.BLFacadeImplementation;

import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RegisterGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField Usernametxt;
	private JPasswordField password1;
	private JPasswordField password2;
	// Lehioaren bisibilitatea kontrolatu ahal izateko
	private JFrame thisFrame; 
	private JTextField emailtxt;
	private JLabel lblIncorrectPassword;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterGUI frame = new RegisterGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegisterGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("RegisterGUI.Username"));
		lblNewLabel.setBounds(37, 63, 123, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewPassword = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("RegisterGUI.Password"));
		lblNewPassword.setBounds(37, 104, 123, 14);
		contentPane.add(lblNewPassword);
		
		JLabel lblConfirmPassword = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("RegisterGUI.CFPassword"));
		lblConfirmPassword.setBounds(37, 151, 143, 14);
		contentPane.add(lblConfirmPassword);
		
		JLabel lblEmail = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("RegisterGUI.Email"));
		lblEmail.setBounds(37, 15, 123, 14);
		contentPane.add(lblEmail);
		
		// Pasahitza zuzena ez dela esaten duen textua, hasieran ez dago aktibatua, ondoren bai
		lblIncorrectPassword = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("RegisterGUI.IncPsswd")); //$NON-NLS-1$ //$NON-NLS-2$
		lblIncorrectPassword.setVisible(false);
		lblIncorrectPassword.setBounds(118, 239, 219, 17);
		contentPane.add(lblIncorrectPassword);
		
		emailtxt = new JTextField();
		emailtxt.setColumns(10);
		emailtxt.setBounds(198, 12, 172, 20);
		contentPane.add(emailtxt);
		
		Usernametxt = new JTextField();
		Usernametxt.setBounds(198, 60, 172, 20);
		contentPane.add(Usernametxt);
		Usernametxt.setColumns(10);
		
		password1 = new JPasswordField();
		password1.setBounds(198, 101, 172, 20);
		contentPane.add(password1);
		
		password2 = new JPasswordField();
		password2.setBounds(198, 146, 172, 20);
		contentPane.add(password2);
		
		JButton btnRegister = new JButton(ResourceBundle.getBundle("Etiquetas").getString("RegisterGUI.RegisterButton"));
		// Kanpoan hasieratzen da, addActionListener barrun ezindalako hasieratu
		thisFrame=this;
		
		btnRegister.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				BLFacade facade = MainGUI.getBusinessLogic();
				
				if(password1.getText().compareTo(password2.getText())==0 && !facade.isRegistered(Usernametxt.getText()) ) {
					// Datu basean sartzen dira datuak, eta erregistratutzat ematen da
					System.out.println("Erregistratu egin da!");
				} else {
					if(facade.isRegistered(Usernametxt.getText())){
						// Dagoeneko erregistratua dagoenez, login pantailara bidali
						thisFrame.setVisible(false);
						JFrame a = new LoginGUI();
						a.setVisible(true);
					} else {
						lblIncorrectPassword.setVisible(true);
					}
				}
			}
		});
		btnRegister.setBounds(118, 186, 219, 45);
		contentPane.add(btnRegister);
		
		
		
		

	}
}
