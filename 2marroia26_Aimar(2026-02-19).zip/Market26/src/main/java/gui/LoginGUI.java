package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_log;
	private JTextField textField_pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(92, 57, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(92, 141, 71, 14);
		contentPane.add(lblNewLabel_1);
		
		textField_log = new JTextField();
		textField_log.setBounds(173, 54, 86, 20);
		contentPane.add(textField_log);
		textField_log.setColumns(10);
		
		textField_pass = new JTextField();
		textField_pass.setBounds(173, 138, 86, 20);
		contentPane.add(textField_pass);
		textField_pass.setColumns(10);
		
		JButton btnSaiatu = new JButton("Try");
		btnSaiatu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BLFacade facade = MainGUI.getBusinessLogic();
				boolean b=facade.isLogged(textField_log.getText(),textField_pass.getText());
				if(b) {
					new MainGUIerregistratua(null).setVisible(true);;
				}else {
					
				}
				
			}
		});
		btnSaiatu.setBounds(173, 185, 89, 23);
		contentPane.add(btnSaiatu);

	}
}
